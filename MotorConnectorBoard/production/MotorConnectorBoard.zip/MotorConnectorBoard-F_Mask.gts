G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.4*
G04 #@! TF.CreationDate,2025-10-27T23:44:39+00:00*
G04 #@! TF.ProjectId,MotorConnectorBoard,4d6f746f-7243-46f6-9e6e-6563746f7242,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.4) date 2025-10-27 23:44:39*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMOutline4P*
0 Free polygon, 4 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 4*
0 $1 to $8 corner X, Y*
0 $9 Rotation angle, in degrees counterclockwise*
0 create outline with 4 corners*
4,1,4,$1,$2,$3,$4,$5,$6,$7,$8,$1,$2,$9*%
G04 Aperture macros list end*
%ADD10R,1.000000X1.150000*%
%ADD11Outline4P,-1.000000X-1.250000X1.000000X-1.250000X0.500000X1.250000X-0.500000X1.250000X0.000000*%
%ADD12R,1.700000X1.700000*%
%ADD13C,1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J3*
X130575000Y-89950000D03*
D11*
X130575000Y-91750000D03*
D10*
X133175000Y-89950000D03*
D11*
X133175000Y-91750000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J2*
X130100000Y-95000000D03*
D13*
X130100000Y-97540000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J1*
X133700000Y-95000000D03*
D13*
X133700000Y-97540000D03*
G04 #@! TD*
M02*
